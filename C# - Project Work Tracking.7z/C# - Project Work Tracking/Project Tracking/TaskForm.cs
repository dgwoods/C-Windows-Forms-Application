﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tracking
{
    public partial class TaskForm : Form
    {
        public TaskForm()
        {
            InitializeComponent();
        }

        private void tasksBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            //inform user of errors in attempting to save data
            try
            {
                this.Validate();
                this.tasksBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.workDataDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void TaskForm_Load(object sender, EventArgs e)
        {
            //Populate status with acceptable values           
            statusComboBox.Items.Add("Pending");
            statusComboBox.Items.Add("Underway");
            statusComboBox.Items.Add("Delayed");
            statusComboBox.Items.Add("Completed");
            //inform user of any errors in trying to read data
            try
            {
                // TODO: This line of code loads data into the 'workDataDataSet.Projects' table. You can move, or remove it, as needed.
                this.projectsTableAdapter.Fill(this.workDataDataSet.Projects);
                // TODO: This line of code loads data into the 'workDataDataSet.Tasks' table. You can move, or remove it, as needed.
                this.tasksTableAdapter.Fill(this.workDataDataSet.Tasks);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //close form
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
