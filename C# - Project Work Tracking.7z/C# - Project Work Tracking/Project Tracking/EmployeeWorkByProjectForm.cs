﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tracking
{
    public partial class EmployeeWorkByProjectForm : Form
    {
        public EmployeeWorkByProjectForm()
        {
            InitializeComponent();
        }

        //Create local instance of dataset
        private WorkDataDataSet ProjectWorkSummation
        {
            get { return ((MainForm)MdiParent).WorkData; }
        }

        private void ShowProjectInfo (int pID)
        {
            //Ready the listview
            SetListViewColumns();
      
            //Get the project row associated with the current project ID
            WorkDataDataSet.ProjectsRow projectInfo = ProjectWorkSummation.Projects.FindByProjectID(pID);
            //Create array of tasks associated with that project
            DataRow[] projectTasks = projectInfo.GetChildRows("FK_Tasks_Projects");

            //Decimal to track total hours spent on project
            decimal hoursWorked = 0;
            foreach (DataRow task in projectTasks)  //For every task row that a project has,
            {
                //Create an array of Work that was completed for that task.
                DataRow[] taskWorkDone = ProjectWorkSummation.WorkDone.Select(string.Format("Task={0}", task["TaskID"].ToString())); 

                foreach (DataRow workDone in taskWorkDone)  //For every instance of work completed for every task of a given project,
                {
                    //Get the employee row of the employee who completed the work.
                    DataRow employee = ProjectWorkSummation.Employees.FindByEmployeeID(Convert.ToInt16(workDone["Employee"]));

                    //Use that row to go back to get their first and last names and use that name to
                    //create a new list view item (LVI).
                    ListViewItem lviWorkDone = new ListViewItem(employee["FirstName"].ToString() + ' ' + employee["LastName"].ToString());
                    lviWorkDone.SubItems.Add(task["Name"].ToString());         //Add the name of the task to the LVI.
                    DateTime justDate = Convert.ToDateTime(workDone["Date"]);  //Convert the date of work done to a datetime.
                    lviWorkDone.SubItems.Add(justDate.ToString("d"));          //Add that date to the LVI, removing the time portion.
                    lviWorkDone.SubItems.Add(workDone["Hours"].ToString());    //Add the hours worked to the LVI
                    //Add the LVI to the listview control
                    lvWorkSummation.Items.Add(lviWorkDone);

                    //Add the number of hours worked for this work instance to the hours worked decimal
                    hoursWorked +=Convert.ToDecimal(workDone["Hours"]);
                }
            }
            //Set the total hours textbox text to the calculated value
            txtHours.Text = hoursWorked.ToString();
        }

        private void projectsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //inform user of any errors while attmpting to save data
            try
            {
                this.Validate();
                this.projectsBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.workDataDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void EmployeeWorkByProjectForm_Load(object sender, EventArgs e)
        {
            SetListViewColumns();
            //Populate status with acceptable values           
            statusComboBox.Items.Add("Pending");
            statusComboBox.Items.Add("Underway");
            statusComboBox.Items.Add("Delayed");
            statusComboBox.Items.Add("Completed");
            //inform user of any errors while attmpting to read data
            try
            {
                // TODO: This line of code loads data into the 'workDataDataSet.Employees' table. You can move, or remove it, as needed.
                this.employeesTableAdapter.Fill(this.workDataDataSet.Employees);
                // TODO: This line of code loads data into the 'workDataDataSet.Tasks' table. You can move, or remove it, as needed.
                this.tasksTableAdapter.Fill(this.workDataDataSet.Tasks);
                // TODO: This line of code loads data into the 'workDataDataSet.WorkDone' table. You can move, or remove it, as needed.
                this.workDoneTableAdapter.Fill(this.workDataDataSet.WorkDone);
                // TODO: This line of code loads data into the 'workDataDataSet.Projects' table. You can move, or remove it, as needed.
                this.projectsTableAdapter.Fill(this.workDataDataSet.Projects);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //close form
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Set the listview's column headers and set to details view
        private void SetListViewColumns()
        {
            lvWorkSummation.Columns.Add("Employee", 120);
            lvWorkSummation.Columns.Add("Task", 282);
            lvWorkSummation.Columns.Add("Date", 100);
            lvWorkSummation.Columns.Add("Hours", 50);
            lvWorkSummation.View = View.Details;
        }

        //Clear and update the listview whenever a change is made to the projectID textbox by passing the ID to the ShowProjectInfo procedure.
        private void projectIDTextBox_TextChanged(object sender, EventArgs e)
        {
            lvWorkSummation.Clear();
            ShowProjectInfo(Convert.ToInt16(projectIDTextBox.Text));
        }
    }
}
