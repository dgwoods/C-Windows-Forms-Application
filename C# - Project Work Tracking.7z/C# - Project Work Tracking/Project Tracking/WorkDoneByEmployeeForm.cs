﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tracking
{
    public partial class WorkDoneByEmployeeForm : Form
    {
        public WorkDoneByEmployeeForm()
        {
            InitializeComponent();
        }

        //Create local instance of dataset
        private WorkDataDataSet EmployeeWorkSummation
        {
            get { return ((MainForm)MdiParent).WorkData; }
        }

        private void ShowEmployeeInfo(int eID)
        {
            //Ready the listview
            SetListViewColumns();
            //Get the employee row associated with the current employee ID
            WorkDataDataSet.EmployeesRow employeeInfo = EmployeeWorkSummation.Employees.FindByEmployeeID(eID);
            //Create array of work instances completed by the employee
            DataRow[] employeeWork = employeeInfo.GetChildRows("FK_WorkDone_Employees");

            //Decimal to track total hours spent on project
            decimal hoursWorked = 0;
            foreach (DataRow work in employeeWork)  //For every instance of work that an employee has completed,
            {
                //Create an array of tasks associated with that work.
                DataRow[] employeeTasksWorked = EmployeeWorkSummation.Tasks.Select(string.Format("TaskID={0}", work["Task"].ToString())); 

                foreach (DataRow task in employeeTasksWorked)  //For every task associated with an instance of work,
                {
                    //Get the project that task is associated with.
                    DataRow project = EmployeeWorkSummation.Projects.FindByProjectID(Convert.ToInt16(task["Project"]));

                    //Use that project row to obtain the name of the project worked on and create a new listview item (LVI)
                    ListViewItem lviWorkInstance = new ListViewItem(project["Name"].ToString());
                    lviWorkInstance.SubItems.Add(task["Name"].ToString());         //Add the name of the task to the LVI.
                    DateTime justDate = Convert.ToDateTime(work["Date"]);          //Convert the date of work done to a datetime.
                    lviWorkInstance.SubItems.Add(justDate.ToString("d"));          //Add that date to the LVI, removing the time portion.
                    lviWorkInstance.SubItems.Add(work["Hours"].ToString());       //Add the hours worked to the LVI
                    //Add the LVI to the listview control
                    lvWorkSummation.Items.Add(lviWorkInstance);

                    //Add the number of hours worked for this work instance to the hours worked decimal
                    hoursWorked +=Convert.ToDecimal(work["Hours"]);
                }
            }
            //Set the total hours textbox text to the calculated value
            txtHours.Text = hoursWorked.ToString();
        }

        private void employeesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //inform user of errors saving
            try
            {
                this.Validate();
                this.employeesBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.workDataDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void WorkDoneByEmployeeForm_Load(object sender, EventArgs e)
        {
            SetListViewColumns();
            //inform user of errors reading
            try
            {
                // TODO: This line of code loads data into the 'workDataDataSet.Employees' table. You can move, or remove it, as needed.
                this.employeesTableAdapter.Fill(this.workDataDataSet.Employees);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Set the listview's column headers and set to details view
        private void SetListViewColumns()
        {
            lvWorkSummation.Columns.Add("Project", 201);
            lvWorkSummation.Columns.Add("Task", 201);
            lvWorkSummation.Columns.Add("Date", 100);
            lvWorkSummation.Columns.Add("Hours", 50);
            lvWorkSummation.View = View.Details;
        }

        //close form
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Clear and update the listview whenever a change is made to the employee ID textbox by passing the ID to the 
        //ShowEmployeeInfo procedure.
        private void employeeIDTextBox_TextChanged(object sender, EventArgs e)
        {
            lvWorkSummation.Clear();
            ShowEmployeeInfo(Convert.ToInt16(employeeIDTextBox.Text));
        }
    }
}
