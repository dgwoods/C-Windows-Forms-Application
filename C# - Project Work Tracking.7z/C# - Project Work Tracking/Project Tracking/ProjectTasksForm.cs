﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tracking
{
    public partial class ProjectTasksForm : Form
    {
        public ProjectTasksForm()
        {
            InitializeComponent();
        }

        private void tasksBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            //Show if any error in attempting to save
            try
            {
                this.Validate();
                this.tasksBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.workDataDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ProjectTasksForm_Load(object sender, EventArgs e)
        {
            //Populate status with acceptable values           
            statusComboBox.Items.Add("Pending");
            statusComboBox.Items.Add("Underway");
            statusComboBox.Items.Add("Delayed");
            statusComboBox.Items.Add("Completed");
            //Show if any error in attempting to read
            try
            {
                // TODO: This line of code loads data into the 'workDataDataSet.Employees' table. You can move, or remove it, as needed.
                this.employeesTableAdapter.Fill(this.workDataDataSet.Employees);            
                // TODO: This line of code loads data into the 'workDataDataSet.Projects' table. You can move, or remove it, as needed.
                this.projectsTableAdapter.Fill(this.workDataDataSet.Projects);
                // TODO: This line of code loads data into the 'workDataDataSet.Tasks' table. You can move, or remove it, as needed.
                this.tasksTableAdapter.Fill(this.workDataDataSet.Tasks);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //close form
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
