﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tracking
{
    public partial class EmployeeForm : Form
    {
        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void employeesBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            //Show user if any errors while attempting to save
            try
            {
                this.Validate();
                this.employeesBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.workDataDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'workDataDataSet.Employees' table.
            //Show user if there's any error while trying to read data
            try
            {
                this.employeesTableAdapter.Fill(this.workDataDataSet.Employees);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        //Close form
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
