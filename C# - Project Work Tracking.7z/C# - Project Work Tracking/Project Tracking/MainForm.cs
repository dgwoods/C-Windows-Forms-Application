﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tracking
{//Derrick Woods - CIS266 Project - June 14, 2018
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            dsWorkData = new WorkDataDataSet(); //instantiate dataset
        }

        //Form dataset and property for access
        private WorkDataDataSet dsWorkData;
        public WorkDataDataSet WorkData
        { get { return dsWorkData; } }

        private void GetData()
        {
            //Table adapters to read db
            WorkDataDataSetTableAdapters.EmployeesTableAdapter taEmployees =
                new WorkDataDataSetTableAdapters.EmployeesTableAdapter();
            WorkDataDataSetTableAdapters.ProjectsTableAdapter taProjects =
                new WorkDataDataSetTableAdapters.ProjectsTableAdapter();
            WorkDataDataSetTableAdapters.TasksTableAdapter taTasks =
                new WorkDataDataSetTableAdapters.TasksTableAdapter();
            WorkDataDataSetTableAdapters.WorkDoneTableAdapter taWorkDone =
                new WorkDataDataSetTableAdapters.WorkDoneTableAdapter();

            try
            {
                //Get data for each table
                taEmployees.Fill(WorkData.Employees);
                taProjects.Fill(WorkData.Projects);
                taTasks.Fill(WorkData.Tasks);
                taWorkDone.Fill(WorkData.WorkDone);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void SaveData()
        {
            //Create table adapters
            WorkDataDataSetTableAdapters.EmployeesTableAdapter taEmployees =
                new WorkDataDataSetTableAdapters.EmployeesTableAdapter();
            WorkDataDataSetTableAdapters.ProjectsTableAdapter taProjects =
                new WorkDataDataSetTableAdapters.ProjectsTableAdapter();
            WorkDataDataSetTableAdapters.TasksTableAdapter taTasks =
                new WorkDataDataSetTableAdapters.TasksTableAdapter();
            WorkDataDataSetTableAdapters.WorkDoneTableAdapter taWorkDone =
                new WorkDataDataSetTableAdapters.WorkDoneTableAdapter();

            //Setup table adapter manager
            WorkDataDataSetTableAdapters.TableAdapterManager taManager =
                new WorkDataDataSetTableAdapters.TableAdapterManager();
            taManager.EmployeesTableAdapter = taEmployees;
            taManager.ProjectsTableAdapter = taProjects;
            taManager.TasksTableAdapter = taTasks;
            taManager.WorkDoneTableAdapter = taWorkDone;

            try
            {
                //Write data to database
                taManager.UpdateAll(WorkData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); //Inform of potential error
            }
        }

        //Close the appplication
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveData();
        }     

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //If there's data not in db, ask if user wants to save
            if (WorkData.HasChanges())
            {
                DialogResult result = MessageBox.Show("Save changes?",
                    "Unsaved Data", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    SaveData();
                }
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            GetData();
        }

        //Procedure to display the selected from by seting the entered 
        //form's mdi parent to this form and useing show()
        private void ShowForm(Form formToShow)
        {
            formToShow.MdiParent = this;
            formToShow.Show();
        }

        //Display child forms in cascade
        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        //Display child forms in horizontal tile
        private void tileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        //Display child forms in vertical tile
        private void tileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void closeAllFormsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form child in this.MdiChildren) //For every child form within the main form
            {
                ActiveMdiChild.Close(); //Close the currently active child form
            }
        }

        //Display Project form using ShowForm
        private void projectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new ProjectForm());
        }
        //Display Task form using ShowForm
        private void taskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new TaskForm());
        }
        //Display Work Done form using ShowForm
        private void workDoneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new WorkDoneForm());
        }
        //Display Employee form using ShowForm
        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new EmployeeForm());
        }
        //Display Work Done by Employee form using ShowForm
        private void employeeWorkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new WorkDoneByEmployeeForm());
        }
        //Display Employee Work by Project form using ShowForm
        private void employeeWorkByProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new EmployeeWorkByProjectForm());
        }
        //Display Project Tasks form using ShowForm
        private void projectTasksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowForm(new ProjectTasksForm());
        }
    }
}
