﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tracking
{
    public partial class ProjectForm : Form
    {
        public ProjectForm()
        {
            InitializeComponent();
        }

        //Close the form
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void projectsBindingNavigatorSaveItem_Click_2(object sender, EventArgs e)
        {
            //Show user if any error while attempting to save 
            try
            {
                this.Validate();
                this.projectsBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.workDataDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Saving");
            }
        }

        private void ProjectForm_Load_1(object sender, EventArgs e)
        {
            //Populate status with acceptable values           
            statusComboBox.Items.Add("Pending");
            statusComboBox.Items.Add("Underway");
            statusComboBox.Items.Add("Delayed");
            statusComboBox.Items.Add("Completed");
            
            //Show user if any error while attempting to read data
            try
            {
                // TODO: This line of code loads data into the 'workDataDataSet.Employees' table. You can move, or remove it, as needed.
                this.employeesTableAdapter.Fill(this.workDataDataSet.Employees);
                // TODO: This line of code loads data into the 'workDataDataSet.Projects' table. You can move, or remove it, as needed.
                this.projectsTableAdapter.Fill(this.workDataDataSet.Projects);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }           
        }
    }
}
