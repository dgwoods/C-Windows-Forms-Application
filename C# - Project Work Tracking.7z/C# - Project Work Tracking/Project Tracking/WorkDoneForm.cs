﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tracking
{
    public partial class WorkDoneForm : Form
    {
        public WorkDoneForm()
        {
            InitializeComponent();
        }

        private void workDoneBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.workDoneBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.workDataDataSet);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void WorkDoneForm_Load(object sender, EventArgs e)
        {
            try
            {
                // TODO: This line of code loads data into the 'workDataDataSet.Employees' table. You can move, or remove it, as needed.
                this.employeesTableAdapter.Fill(this.workDataDataSet.Employees);
                // TODO: This line of code loads data into the 'workDataDataSet.Tasks' table. You can move, or remove it, as needed.
                this.tasksTableAdapter.Fill(this.workDataDataSet.Tasks);            
                // TODO: This line of code loads data into the 'workDataDataSet.WorkDone' table. You can move, or remove it, as needed.
                this.workDoneTableAdapter.Fill(this.workDataDataSet.WorkDone);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //close form
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
